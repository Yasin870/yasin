package dev.droidfps.mixin.gl;

import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** glGetError, GL4ES/MobileGlues uzerinde her seferinde cevirici round-trip'i. Release'te gereksiz. */
@Mixin(value = GL11.class, remap = false)
public class GlErrorMixin {
    @Inject(method = "glGetError", at = @At("HEAD"), cancellable = true, require = 0)
    private static void droidfps$skipGetError(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(0);
    }
}
