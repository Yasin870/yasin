package dev.droidfps.mixin.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/** glGetError, GL4ES/MobileGlues uzerinde her seferinde cevirici round-trip'i. Release'te gereksiz. */
@Mixin(value = GlStateManager.class, remap = true)
public class GlErrorMixin {

    /**
     * @author droidfps
     * @reason Skip glGetError round-trip on mobile GL translators
     */
    @Overwrite
    public static int _getError() {
        return 0;
    }
}
